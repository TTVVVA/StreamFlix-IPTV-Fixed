const TEXT_TYPES = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".mjs": "text/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".svg": "image/svg+xml; charset=utf-8",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".webp": "image/webp",
  ".ico": "image/x-icon"
};

const CORS = {
  "access-control-allow-origin": "*",
  "access-control-allow-methods": "GET, POST, OPTIONS",
  "access-control-allow-headers": "Content-Type, Accept"
};

function jsonResponse(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { ...CORS, "content-type": "application/json; charset=utf-8" }
  });
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const pathname = url.pathname;

    // ── CORS preflight ──────────────────────────────────────────────────────
    if (request.method === "OPTIONS") {
      return new Response(null, { status: 204, headers: CORS });
    }

    // ── ROTA: /.proxy/channels-api/ ─────────────────────────────────────────
    // O frontend chama esta rota para obter a lista de canais.
    // Este worker reencaminha para o streamflix-v2-channels worker.
    if (pathname.startsWith("/.proxy/channels-api")) {
      const m3uUrl = url.searchParams.get("url") || env.DEFAULT_M3U || "";

      if (!m3uUrl) {
        return jsonResponse({ ok: false, error: "Sem URL de playlist configurada. Define DEFAULT_M3U no wrangler.toml." }, 400);
      }

      const channelsWorkerUrl =
        `https://streamflix-v2-channels.${env.ACCOUNT_ID || "874a220e5e5bae3c5edcb7497a55635b"}.workers.dev/?url=${encodeURIComponent(m3uUrl)}`;

      try {
        const resp = await fetch(channelsWorkerUrl, {
          headers: {
            "User-Agent": "VLC/3.0.18 LibVLC/3.0.18",
            "Accept": "application/json"
          },
          cf: { cacheTtl: 60, cacheEverything: false }
        });

        if (!resp.ok) {
          return jsonResponse({ ok: false, error: `channels-worker devolveu HTTP ${resp.status}` }, 502);
        }

        const data = await resp.json();
        return jsonResponse(data);
      } catch (err) {
        return jsonResponse({ ok: false, error: `Erro ao contactar channels-worker: ${err.message}` }, 500);
      }
    }

    // ── ROTA: /.proxy/stream-proxy ──────────────────────────────────────────
    // Proxy para streams HLS — necessário porque o Discord bloqueia
    // fetch() direto a domínios externos dentro do iframe da Activity.
    if (pathname.startsWith("/.proxy/stream-proxy")) {
      const streamUrl = url.searchParams.get("url");

      if (!streamUrl) {
        return new Response("Parâmetro 'url' em falta", { status: 400, headers: CORS });
      }

      // Validação básica: só HTTP/HTTPS
      let parsedUrl;
      try {
        parsedUrl = new URL(streamUrl);
        if (!["http:", "https:"].includes(parsedUrl.protocol)) {
          throw new Error("Protocolo não suportado");
        }
      } catch (_) {
        return new Response("URL inválida", { status: 400, headers: CORS });
      }

      try {
        const resp = await fetch(streamUrl, {
          headers: {
            "User-Agent": "VLC/3.0.18 LibVLC/3.0.18",
            "Referer": parsedUrl.origin + "/",
            "Origin": parsedUrl.origin,
            "Accept": "*/*"
          }
        });

        const contentType = resp.headers.get("content-type") || "application/octet-stream";

        // Para playlists M3U8: reescreve URLs relativas para passarem pelo proxy
        if (contentType.includes("mpegurl") || streamUrl.endsWith(".m3u8")) {
          let body = await resp.text();
          const base = new URL(streamUrl);

          // Reescreve segmentos relativos e sub-playlists para passarem pelo proxy
          body = body.replace(/^(?!#)(.+\.m3u8.*)$/gm, (match) => {
            try {
              const absUrl = new URL(match.trim(), base).toString();
              return `/.proxy/stream-proxy?url=${encodeURIComponent(absUrl)}`;
            } catch (_) { return match; }
          });
          body = body.replace(/^(?!#)(.+\.ts.*)$/gm, (match) => {
            try {
              const absUrl = new URL(match.trim(), base).toString();
              return `/.proxy/stream-proxy?url=${encodeURIComponent(absUrl)}`;
            } catch (_) { return match; }
          });

          return new Response(body, {
            status: resp.status,
            headers: {
              ...CORS,
              "content-type": "application/vnd.apple.mpegurl"
            }
          });
        }

        // Para segmentos .ts e outros binários: pass-through direto
        return new Response(resp.body, {
          status: resp.status,
          headers: {
            ...CORS,
            "content-type": contentType
          }
        });
      } catch (err) {
        return new Response(`Erro no proxy: ${err.message}`, { status: 502, headers: CORS });
      }
    }

    // ── ROTA: assets estáticos (HTML/JS/CSS) ────────────────────────────────
    // Comportamento original preservado na íntegra.
    const assetPath = pathname === "/" ? "/index.html" : pathname;
    try {
      const asset = await env.ASSETS.fetch(new Request(new URL(assetPath, request.url), request));

      if (asset.ok) {
        const ext = assetPath.substring(assetPath.lastIndexOf("."));
        const contentType = TEXT_TYPES[ext] || asset.headers.get("content-type");

        let response = asset;
        if (ext === ".html") {
          let html = await asset.text();
          html = html.replace(/__DISCORD_CLIENT_ID__/g, env.DISCORD_CLIENT_ID || "");
          response = new Response(html, {
            headers: { "content-type": "text/html; charset=utf-8" }
          });
        }

        const newHeaders = new Headers(response.headers);
        if (contentType) newHeaders.set("content-type", contentType);
        newHeaders.set("access-control-allow-origin", "*");

        return new Response(response.body, {
          status: response.status,
          headers: newHeaders
        });
      }

      // Fallback SPA → index.html
      const index = await env.ASSETS.fetch(new Request(new URL("/index.html", request.url), request));
      return new Response(index.body, {
        status: 200,
        headers: {
          "content-type": "text/html; charset=utf-8",
          "access-control-allow-origin": "*"
        }
      });
    } catch (err) {
      return new Response("Not Found", { status: 404 });
    }
  }
};
