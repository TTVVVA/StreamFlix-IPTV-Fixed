export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const corsHeaders = {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type",
    };

    if (request.method === "OPTIONS") {
      return new Response(null, { headers: corsHeaders });
    }

    const m3uUrl = url.searchParams.get("url") || env.DEFAULT_M3U;
    const group = url.searchParams.get("group"); // se vier group, filtra por categoria
    const onlyGroups = url.searchParams.get("onlyGroups") === "1"; // só devolve lista de categorias

    if (!m3uUrl) {
      return json({ ok: false, error: "Sem URL de playlist" }, 400, corsHeaders);
    }

    try {
      const response = await fetch(m3uUrl, {
        headers: {
          "User-Agent": "VLC/3.0.18 LibVLC/3.0.18",
          "Accept": "*/*"
        }
      });

      if (!response.ok) {
        return json({ ok: false, error: `Falha ao carregar M3U: ${response.status}` }, 502, corsHeaders);
      }

      const text = await response.text();
      const { channels, groups } = parseM3u(text, m3uUrl);

      // Modo 1: só devolve as categorias (rápido, sem canais)
      if (onlyGroups) {
        return json({ ok: true, groups }, 200, corsHeaders);
      }

      // Modo 2: devolve canais de uma categoria específica
      if (group) {
        const filtered = channels.filter(c => c.group === group);
        return json({ ok: true, group, channels: filtered }, 200, corsHeaders);
      }

      // Modo 3: devolve tudo (compatibilidade — limitado a 150)
      return json({ ok: true, channels: channels.slice(0, 150) }, 200, corsHeaders);

    } catch (err) {
      return json({ ok: false, error: err.message }, 500, corsHeaders);
    }
  }
};

function json(data, status, headers) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { ...headers, "Content-Type": "application/json" }
  });
}

function parseM3u(text, baseUrl) {
  const lines = text.split(/\r?\n/);
  const channels = [];
  const groupSet = new Set();
  let currentItem = null;

  for (const rawLine of lines) {
    const line = rawLine.trim();
    if (!line) continue;

    if (line.startsWith("#EXTINF")) {
      currentItem = { name: "Canal", group: "Geral", logo: "", id: "" };

      const groupMatch = line.match(/group-title="([^"]+)"/i);
      if (groupMatch) currentItem.group = groupMatch[1];

      const idMatch = line.match(/tvg-id="([^"]+)"/i);
      if (idMatch) currentItem.id = idMatch[1];

      const logoMatch = line.match(/tvg-logo="([^"]+)"/i);
      if (logoMatch) currentItem.logo = logoMatch[1];

      const commaIndex = line.lastIndexOf(",");
      if (commaIndex !== -1) {
        currentItem.name = line.substring(commaIndex + 1).trim();
      }
      continue;
    }

    if (line.startsWith("#")) continue;

    if (currentItem) {
      try {
        const channelUrl = new URL(line, baseUrl).toString();
        groupSet.add(currentItem.group);
        channels.push({ ...currentItem, url: channelUrl });
      } catch (e) {}
      currentItem = null;
    }
  }

  // Devolve grupos com contagem de canais
  const groups = Array.from(groupSet).map(name => ({
    name,
    count: channels.filter(c => c.group === name).length
  })).sort((a, b) => a.name.localeCompare(b.name));

  return { channels, groups };
}
