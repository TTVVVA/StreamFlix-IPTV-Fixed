// ════════════════════════════════════════════════════════════════════════════
// SUBSTITUI as funções loadChannels, renderChannels e markEmptyChannels
// no teu app.js existente
// ════════════════════════════════════════════════════════════════════════════

// Estado extra para categorias (adiciona ao objeto `state` existente)
// state.groups = []          → lista de categorias
// state.activeGroup = null   → categoria selecionada
// state.groupChannels = {}   → cache de canais por categoria

// ── Carrega só as categorias (chamada inicial, muito rápida) ─────────────────
async function loadGroups(m3uUrl) {
  await logEvent("groups_fetch_start", { url: m3uUrl });
  setDiag(refs.sessionDiag, "warn", "Categorias: a carregar");

  const apiUrl = `/.proxy/channels-api/?url=${encodeURIComponent(m3uUrl)}&onlyGroups=1`;

  try {
    const resp = await fetch(apiUrl);
    if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
    const data = await resp.json();

    if (!data.ok || !data.groups?.length) {
      throw new Error(data.error || "Sem categorias");
    }

    state.groups = data.groups;
    state.channels = [];
    state.activeGroup = null;

    renderGroupList();
    setDiag(refs.sessionDiag, "ok", `${data.groups.length} categorias`);
    showToast("Categorias carregadas.", `${data.groups.length} grupos encontrados.`);
    await logEvent("groups_fetch_ok", { count: data.groups.length });

  } catch (err) {
    setDiag(refs.sessionDiag, "error", "Erro ao carregar categorias");
    showToast("Erro.", err.message, "error");
    await logEvent("groups_fetch_error", { error: err.message });
  }
}

// ── Carrega os canais de uma categoria específica (ao clicar) ────────────────
async function loadChannels(m3uUrl, group) {
  // Se não vier group, carrega só as categorias
  if (!group) {
    return loadGroups(m3uUrl);
  }

  // Usa cache se já carregou esta categoria
  if (state.groupChannels?.[group]) {
    state.channels = state.groupChannels[group];
    state.activeGroup = group;
    renderChannels();
    return;
  }

  await logEvent("channels_fetch_start", { url: m3uUrl, group });
  setDiag(refs.sessionDiag, "warn", `A carregar: ${group}`);

  const apiUrl = `/.proxy/channels-api/?url=${encodeURIComponent(m3uUrl)}&group=${encodeURIComponent(group)}`;

  try {
    const resp = await fetch(apiUrl);
    if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
    const data = await resp.json();

    if (!data.ok) throw new Error(data.error || "Erro desconhecido");

    // Guarda em cache
    if (!state.groupChannels) state.groupChannels = {};
    state.groupChannels[group] = data.channels || [];

    state.channels = data.channels || [];
    state.activeGroup = group;
    renderChannels();

    setDiag(refs.sessionDiag, "ok", `${state.channels.length} canais`);
    showToast(`${group}`, `${state.channels.length} canais carregados.`);
    await logEvent("channels_fetch_ok", { group, count: state.channels.length });

  } catch (err) {
    setDiag(refs.sessionDiag, "error", "Erro ao carregar canais");
    showToast("Erro.", err.message, "error");
    await logEvent("channels_fetch_error", { group, error: err.message });
  }
}

// ── Renderiza a lista de categorias ──────────────────────────────────────────
function renderGroupList() {
  refs.channelCount.textContent = `${state.groups.length} categorias`;
  refs.channelsList.innerHTML = "";

  if (!state.groups.length) {
    refs.channelsList.innerHTML = `<div class="channel-item is-empty">Sem categorias</div>`;
    return;
  }

  const m3uUrl = state.session?.channelsUrl || new URLSearchParams(location.search).get("url") || DEFAULT_M3U;
  const fragment = document.createDocumentFragment();

  state.groups.forEach(({ name, count }) => {
    const button = document.createElement("button");
    button.className = "channel-item channel-group-item";
    button.type = "button";
    button.innerHTML = `
      <span class="channel-name">${escapeHtml(name)}</span>
      <span class="channel-count">${count} canais</span>
    `;
    button.addEventListener("click", () => {
      markUserGesture("group.click");
      // Marca grupo ativo visualmente
      refs.channelsList.querySelectorAll(".channel-group-item").forEach(b => b.classList.remove("active"));
      button.classList.add("active");
      loadChannels(m3uUrl, name);
    });
    fragment.appendChild(button);
  });

  refs.channelsList.appendChild(fragment);
}

// ── Renderiza lista de canais (igual ao original, mas com botão "← Voltar") ──
function renderChannels(filter = "") {
  const normalized = filter.trim().toLowerCase();
  const visible = state.channels
    .map((channel, index) => ({ channel, index }))
    .filter(({ channel }) => (channel.name || "").toLowerCase().includes(normalized));

  refs.channelCount.textContent = `${visible.length} canais`;
  refs.channelsList.innerHTML = "";

  // Botão de voltar às categorias
  const backBtn = document.createElement("button");
  backBtn.className = "channel-item channel-back-item";
  backBtn.type = "button";
  backBtn.innerHTML = `<span class="channel-name">← Categorias</span>`;
  backBtn.addEventListener("click", () => {
    state.channels = [];
    state.activeGroup = null;
    renderGroupList();
  });
  refs.channelsList.appendChild(backBtn);

  if (!visible.length) {
    refs.channelsList.innerHTML += `<div class="channel-item is-empty">Lista vazia</div>`;
    return;
  }

  const fragment = document.createDocumentFragment();
  visible.forEach(({ channel, index }) => {
    const button = document.createElement("button");
    button.className = `channel-item${index === state.activeIndex ? " active" : ""}`;
    button.type = "button";
    button.dataset.index = String(index);
    button.innerHTML = `
      <span class="channel-number">${index + 1}</span>
      <span class="channel-name">${escapeHtml(channel.name || `Canal ${index + 1}`)}</span>
      <span class="signal" aria-hidden="true"><i></i><i></i><i></i></span>
    `;
    button.addEventListener("click", () => {
      markUserGesture("channel.click");
      selectChannel(index, { autoplay: true });
    });
    fragment.appendChild(button);
  });

  refs.channelsList.appendChild(fragment);
}

function markEmptyChannels() {
  refs.channelCount.textContent = "0 canais";
  refs.channelsList.innerHTML = `<div class="channel-item is-empty">Lista vazia</div>`;
}
