// Substitui APENAS o bloco da rota /.proxy/channels-api no worker.js existente

// ── ROTA: /.proxy/channels-api/ ─────────────────────────────────────────────
if (pathname.startsWith("/.proxy/channels-api")) {
  const m3uUrl = url.searchParams.get("url") || env.DEFAULT_M3U || "";
  const group = url.searchParams.get("group") || "";
  const onlyGroups = url.searchParams.get("onlyGroups") || "";

  if (!m3uUrl) {
    return jsonResponse({ ok: false, error: "Sem URL configurada" }, 400);
  }

  // Constrói URL para o channels-worker
  const cwUrl = new URL("https://streamflix-v2-channels.874a220e5e5bae3c5edcb7497a55635b.workers.dev/");
  cwUrl.searchParams.set("url", m3uUrl);
  if (group) cwUrl.searchParams.set("group", group);
  if (onlyGroups) cwUrl.searchParams.set("onlyGroups", onlyGroups);

  try {
    const resp = await fetch(cwUrl.toString(), {
      headers: { "User-Agent": "VLC/3.0.18 LibVLC/3.0.18" }
    });
    if (!resp.ok) {
      return jsonResponse({ ok: false, error: `channels-worker: HTTP ${resp.status}` }, 502);
    }
    const data = await resp.json();
    return jsonResponse(data);
  } catch (err) {
    return jsonResponse({ ok: false, error: err.message }, 500);
  }
}
